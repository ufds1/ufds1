(function($) {
	$('.liquid').imgLiquid();
})(jQuery);