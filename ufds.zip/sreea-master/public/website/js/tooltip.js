(function($) {
	$('.tooltip').tooltipster({
		animation: 'grow',
		delay: 100,
		position: 'bottom'
	});
})(jQuery);