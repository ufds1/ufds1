(function($) {
	$( '.post-tab' ).xmtab({
		startOn: 1
	});
})(jQuery);