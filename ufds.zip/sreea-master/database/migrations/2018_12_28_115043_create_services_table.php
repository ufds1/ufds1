<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateServicesTable extends Migration {

	public function up()
	{
		Schema::create('services', function(Blueprint $table) {
			$table->increments('id');
            $table->unsignedInteger('user_id');
            $table->unsignedInteger('section_id');
            $table->unsignedInteger('area_id');
            $table->string('name');
            $table->text('body');
            $table->integer('price');
            $table->double('lng')->nullable();
            $table->double('lat')->nullable();
            $table->enum('per',['Hour', 'Service']);
            $table->enum('status',['active','inactive'])->default('inactive');
            $table->timestamps();
        });
	}

	public function down()
	{
		Schema::drop('services');
	}
}