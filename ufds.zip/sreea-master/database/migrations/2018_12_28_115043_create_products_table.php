<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProductsTable extends Migration {

	public function up()
	{
		Schema::create('products', function(Blueprint $table) {
			$table->increments('id');
            $table->integer('section_id');
            $table->integer('user_id');
            $table->integer('branch_id')->nullable();
            $table->string('name');
			$table->string('body');
            $table->float('price', 10, 0);
			$table->enum('in_stock', ['Yes', 'No']);
			$table->string('sku');
            $table->enum('status',['active','inactive'])->default('inactive');
            $table->timestamps();
        });
	}

	public function down()
	{
		Schema::drop('products');
	}
}