<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
//        $this->call(SettingsTableseeder::class);
        $this->call(AreaTableSeeder::class);
//        $this->call(PermissionTableSeeder::class);
        DB::table('settings')->insert([
            [
                'user_id' => '1',
                'status' => 'Active',
                'shipping_address_id' => '1',
                'currency_id' => '1',
                'data' => '{}',
                'comment' => '1',
                'invoice_date' => '2018-09-16 10:57:03',
                'delivery_date' => '2018-09-16 10:57:03',
                'total_amount' => '12',
                'total_discount' => '1',
                'total_shipping' => '1',
                'total' => '13',
            ],
        ]);

    }
}
