<?php

use Illuminate\Database\Seeder;

class AreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('areas')->insert([
            0 =>
                array (
                    'id' => 1,
                    'area_type' => 1,
                    'name' => 'مصر',
                    'parent_id' => 0,
                    'created_at' => '2018-09-16 10:57:03',
                    'updated_at' => '2018-09-16 10:57:03',
                ),
            1 =>
                array (
                    'id' => 2,
                    'area_type' => 2,
                    'name' => 'القاهرة الكبري',
                    'parent_id' => 1,
                    'created_at' => '2018-01-16 18:47:16',
                    'updated_at' => '2018-01-16 18:47:16',
                ),
            2 =>
                array (
                    'id' => 3,
                    'area_type' => 2,
                    'name' => 'القاهرة الجديدة',
                    'parent_id' => 1,
                    'created_at' => '2018-01-16 18:47:16',
                    'updated_at' => '2018-01-16 18:47:16',
                ),
        ]);
    }
}
