<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Watson\Validating\ValidatingTrait;

class Page extends Model
{
    protected $fillable = [
        'title',
        'slug',
        'body',
        'status',
        'cover',
    ];

    protected $casts = [
        'title' => 'array',
        'body' => 'array',
    ];

//    function getTitleAttribute()
//    {
//        return json_decode($this->attributes['title'], true)[app()->getLocale()];
//    }
//
//    function getBodyAttribute()
//    {
//        return json_decode($this->attributes['body'], true)[app()->getLocale()];
//    }

    public $rules = [
        'title.*'   => 'required',
        'slug'   => 'required',
        'body.*'   => 'required',
    ];

}
