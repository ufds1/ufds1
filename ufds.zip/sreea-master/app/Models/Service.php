<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    protected $guarded = ['id'];

    public $rules = [
        'user_id'   => 'required',
        'section_id'   => 'required',
        'area_id'   => 'required',
        'name'   => 'required',
        'body'   => 'required',
        'price'   => 'required',
        'per'   => 'required',
        'status'   => 'required',
    ];

    public function attachments()
    {
        return $this->morphMany(Attachment::class, 'attachable');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function section()
    {
        return $this->belongsTo(Section::class);
    }

    public function area()
    {
        return $this->belongsTo(Area::class);
    }


}
